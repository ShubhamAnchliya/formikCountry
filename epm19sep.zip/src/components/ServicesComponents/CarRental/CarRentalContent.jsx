import React from 'react'

const CarRentalContent = () => {
  return (
    <div className='carRentalContent text-center'>Lorem Ipsum is probably the most popular dummy text generator out there</div>
  )
}

export default CarRentalContent;