import React, { useContext, useEffect, useState } from "react";
import Select from "react-select";
import qs from "query-string";
import urlJoin from "url-join";
import { InfiniteLoader, List, AutoSizer } from "react-virtualized";
import { range } from "ramda";
import { faker } from "@faker-js/faker";
import axios from "axios";
import { SearchContext } from "../../../pages/Home";


const ReactVirtualizedS = () => {
    
    const [selectedCountry, setSelectedCountry] = useState();
    const [countries, setCountries] = useState([]);
    const [cities, setCities] = useState([]);
    const [selectedCity, setSelectedCity] = useState();
    // const [selectedCategory, setSelectedCategory] = useState();
    const [submit, setSubmit] = useState("");
    const [dropdownData, setDropDownData] = useState([]);
    const { searchData, setSearchData } = useContext(SearchContext);
  
    const fetchCountries = async () => {
      try {
        const countrylist = await axios.get(
          "https://countriesnow.space/api/v0.1/countries"
        );
        setCountries(countrylist.data.data);
        console.log("setCountries", countrylist.data.data);
        let countryvalue = countrylist?.data?.data.map((i, key) => {
          return {
            value: i.country,
            label: i.country,
            cities: i.cities.map((i) => {
              return { value: i, label: i };
            }),
          };
        });
  
        setDropDownData(countryvalue);
  
        console.log("countryvalue", countryvalue);
      } catch (error) {
        console.log(error);
      }
    };

    const handlecountry = (selectedCountry) => {
        setSelectedCountry(selectedCountry);
        console.log("HandleSelectedCountry", selectedCountry);
        if (selectedCountry) {
          setCities(selectedCountry?.cities);
          setSelectedCity(null);
        }
      };
  

const url = "https://countriesnow.space/api/v0.1/countries";
const pageSize = 10;
const maxPage = 10;
const rowCount = pageSize * maxPage;
const rowHeight = 30;
const maxListheight = pageSize * rowHeight;





const fetch = (url) => {
  const {
    query: { page },
  } = qs.parseUrl(url);

  const pageNumber = Number(page);
  const start = pageNumber * pageSize;
console.log("dropdown", dropdownData)

  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve({
          json: () => Promise.resolve(dropdownData.slice(start, start + pageSize)),
        }),
      2000
    )
  );
};


  const [loading, setLoading] = useState(false);
  const [collection, setCollection] = useState([]);

  const fetchReposByPage = (newPage) => {

    const query = qs.stringify({ per_page: pageSize, page: newPage });
    const reposByPage = urlJoin(url, "?" + query);

    return fetch(reposByPage)
    
      .then((res) => res.json())
      .then((data) => {
        console.log("data", data);
        setLoading(false);
        setCollection(collection.concat(data));

console.log("collection", collection.concat(data));

      });
  };
  
  useEffect(() => {
    setLoading(true);

    fetchReposByPage(1);

    fetchCountries();


  }, []);

  const options = collection.map((i) => {
 
    return i

  });

  console.log("optn", options);

  const loadMoreRows = ({ startIndex }) => {
    const newPage = Math.floor(startIndex / pageSize + 1);
    console.log("newPage",newPage);
    return fetchReposByPage(newPage);
  };

  const currentListHeight = pageSize * rowHeight;
  const listHeight =
    collection.length > currentListHeight ? maxListheight : currentListHeight;

  const MenuList = ({ children, ...menuListProps }) => {
    console.log("menuListProps",menuListProps);
    const childrenArray = React.Children.toArray(children);

    const rowRenderer = ({ index, isScrolling, isVisible, style, ...rest }) => {
      const child = childrenArray[index];
      return (
        <div
          style={{
            borderBottom: "1px solid #ccc",
            display: "flex",
            alignItems: "center",
            ...style,
          }}
          {...rest}
        >
          {child ? child : `${index}. Loading...`}
        </div>
      );
    };
    return (
      <InfiniteLoader
        isRowLoaded={({ index }) => !!collection[index]}
        loadMoreRows={loadMoreRows}
        rowCount={rowCount}
        threshhold={5}
      >
        {({ onRowsRendered, registerChild }) => (
          <AutoSizer disableHeight>
            {({ width }) => (
              <List
                height={listHeight}
                onRowsRendered={onRowsRendered}
                ref={registerChild}
                rowCount={rowCount}
                rowHeight={rowHeight}
                rowRenderer={rowRenderer}
                width={width}
              />
            )}
          </AutoSizer>
        )}
      </InfiniteLoader>
    );
  };

  return (
    <div className="countrySelector ">
        <div className="mt-4 w-25">
        <Select

            id="selectCountry"
            onChange={handlecountry}
            value={selectedCountry}
        //   options={dropdownData}
            placeholder={"Country"}

            defaultMenuIsOpen={false}
            isLoading={loading}
            options={options}
            components={{
            MenuList,
            }}
        />
        </div>

        <div className="form-group me-3 ">
                <Select
                id="selectCity"
                onChange={setSelectedCity}
                value={selectedCity}
                options={cities}
                placeholder={"City"}
                styles={{
                    placeholder: (base) => ({
                    ...base,
                    paddingLeft: "10px",
                    }),
                    valueContainer: (base) => ({
                    ...base,
                    paddingLeft: "2rem",
                    }),
                }}
                />

                {/* <label className="input-icon2">
                <BiMapPin />
                </label> */}
            </div>

    </div>


  );
};
export default ReactVirtualizedS;
