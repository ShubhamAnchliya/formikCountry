import axios from "axios";
import React, { useEffect, useState } from "react";
import { BiMapPin } from "react-icons/bi";
import "./PackagesContent.css";
import Select from "react-select";

import { createSearchParams, useNavigate } from "react-router-dom";
import { createContext } from "react";
import { useContext } from "react";
import { SearchContext } from "../../../pages/Home";

const PackagesContent = () => {
  const [selectedCountry, setSelectedCountry] = useState();
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState();
  // const [selectedCategory, setSelectedCategory] = useState();
  const [submit, setSubmit] = useState("");
  const [dropdownData, setDropDownData] = useState([]);
  const { searchData, setSearchData } = useContext(SearchContext);

  const fetchCountries = async () => {
    try {
      const countrylist = await axios.get(
        "https://countriesnow.space/api/v0.1/countries"
      );
      setCountries(countrylist.data.data);
      console.log("setCountries", countrylist.data.data);
      let countryvalue = countrylist?.data?.data.map((i, key) => {
        return {
          value: i.country,
          label: i.country,
          cities: i.cities.map((i) => {
            return { value: i, label: i };
          }),
        };
      });

      setDropDownData(countryvalue);

      console.log("countryvalue", countryvalue);
    } catch (error) {
      console.log(error);
    }
  };

  const handlecountry = (selectedCountry) => {
    setSelectedCountry(selectedCountry);
    console.log("HandleSelectedCountry", selectedCountry);
    if (selectedCountry) {
      setCities(selectedCountry?.cities);
      setSelectedCity(null);
    }
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  console.log("selectedCountry", selectedCountry);
  console.log("selectedCity", selectedCity);

  const onSubmit = () => {
    // console.log("setselectedCountry",selectedCountry.value);

    if (
      selectedCountry.value &&
      selectedCity.value
      // && selectedCategory
    ) {
      setSubmit(true);

      setSearchData(selectedCountry?.value);
    }
  };
  function getScroll(e){
    console.log("e",e)
  }

  return (
    <>
      <div className="packageDiv container">
        <div className="countrySelector ">
          <div className="form-group me-3  " onScroll={(e) =>getScroll(e)}>
            <Select
              id="selectCountry"
              onChange={handlecountry}
              value={selectedCountry}
              options={dropdownData}
              placeholder={"Country"}
              styles={{
                placeholder: (base) => ({
                  ...base,
                  paddingLeft: "10px",
                }),
                valueContainer: (base) => ({
                  ...base,
                  paddingLeft: "2rem",
                }),
              }}
            />

            <label className="input-icon1">
              <BiMapPin />
            </label>
          </div>

          <div className="form-group me-3 ">
            <Select
              id="selectCity"
              onChange={setSelectedCity}
              value={selectedCity}
              options={cities}
              placeholder={"City"}
              styles={{
                placeholder: (base) => ({
                  ...base,
                  paddingLeft: "10px",
                }),
                valueContainer: (base) => ({
                  ...base,
                  paddingLeft: "2rem",
                }),
              }}
            />

            <label className="input-icon2">
              <BiMapPin />
            </label>
          </div>

          {/* <div className="form-group me-3">

              <select 
                name="Category"
                className="form-control  select-category " 
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedCategory}
                id="selectCategory"
              >

                <option>
                  Select Category
                </option>

                {availableCategory?.categories.map((e, key) => {
                    return (
                      <option value={e.name} key={key}>
                        {e}
                      </option>
                    );
                  })}

              </select>

              </div> */}

          <button
            className="searchpackagebtn "
            type="button"
            onClick={onSubmit}
          >
            Search
          </button>
        </div>
        {/* {submit && (
          <div>
            <h3 className="headingC mt-3">
              country {selectedCountry?.value}, city {selectedCity?.value}
              and category {selectedCategory} 
            </h3>
          </div>
        )} */}
      </div>
    </>
  );
};

export default PackagesContent;
