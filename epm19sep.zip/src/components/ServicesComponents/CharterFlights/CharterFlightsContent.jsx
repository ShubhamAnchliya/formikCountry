import React , { useState } from 'react';
import "./CharterFlightsContent.css";
import { BiMapPin } from "react-icons/bi";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { AiTwotoneCalendar } from "react-icons/ai";
import { BsFillFilePersonFill } from "react-icons/bs";

const CharterFlightsContent = () => {

  const [startDate, setStartDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(new Date());

  return (

    <>

      <div className='charterflightContent'>

        <div className='charterflightContent-one'>

          <div className="form-check form-check-inline">
            <input className="form-check-input " type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
            <label className="form-check-label" htmlFor="inlineRadio1">Return</label>
          </div>

          <div className="form-check form-check-inline">
            <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
            <label className="form-check-label" htmlFor="inlineRadio2">One - way</label>
          </div>

          <div className="form-check form-check-inline">
            <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
            <label className="form-check-label" htmlFor="inlineRadio2">Multi - City</label>
          </div>
       
        </div>

        <div className='charterflightContent-two mt-3'>

          <div className="input-wrapper me-2">
            <input className='leavingfrom' placeholder='Leaving from' />
            <label className="input-icon"><BiMapPin /></label>
          </div>

          <div className="input-wrapper me-2">
            <input className='goingto' placeholder='Going to' />
            <label className="input-icon"><BiMapPin /></label>
          </div>


          <div className='input-wrapperd me-2'>
        
            <DatePicker
              className='input'
              dateFormat="dd MMM"            
              selected={startDate}
              minDate={new Date() }
              maxDate={new Date(2023, 1, 29)}            
              onChange={(date) => setStartDate(date)}            
            />

            <label className="input-icon2"><AiTwotoneCalendar /></label>

            <label className="input-icon3">Departing</label>

          </div>

          <div className='input-wrapperd  me-2'>         

            <DatePicker
              className='input'
              dateFormat="dd MMM"
              selected={returnDate}
              minDate={new Date() }
              maxDate={new Date(2023, 1, 29)}           
              onChange={(date) => setReturnDate(date)}
            />

            <label className="input-icon2"><AiTwotoneCalendar /></label>

            <label className="input-icon3"> Returning</label>

          </div>


          <div className='input-wrapperd me-2'>      

            <select className="form-control" aria-label="Default select example">
       
            {Array(5).fill(0).map((item,idx)=>  <option defaultValue="1"  key={idx} >{idx+1} Traveler</option>)}
          
            </select>

            <label className="input-icon2"><BsFillFilePersonFill /></label>

            <label className="input-icon3">Travelers</label>

          </div>

          <button  className='charterflightsearchbtn ' 
            type='button'
       
             >Search</button>
     
        </div>

      </div>

    </>

  )
}

export default CharterFlightsContent;