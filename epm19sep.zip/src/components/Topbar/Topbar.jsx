import React from 'react';

const Topbar = () => {
  return (
    <>
    
        <div className="container-fluid bg-danger">
            <div className="row py-2 px-lg-5">
            <div className="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div className="d-inline-flex align-items-center text-white ms-3">
                <small>
                    <i className="mr-2"></i>+012 345 6789
                </small>
                {/* <small className="px-3"></small> */}
                <small>
                    <i className="mr-2 px-3"></i>info@example.com
                </small>
                <small>
                    <i className="mr-2 px-3"></i>Our blog
                </small>
                </div>
            </div>
            </div>
        </div>

    </>
  )
}

export default Topbar;