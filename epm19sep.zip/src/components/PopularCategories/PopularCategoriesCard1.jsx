import React from "react";
import "./PopularCategoriesCard1.css";
import bgImg1 from "../../assets/bgImg2.jpg";

const PopularCategoriesCard1 = () => {
  return (
    <>

    <div className="categoriescard1 my-2 mb-4">
    
      <div
        className="card"
        style={{
          backgroundImage: `url(${bgImg1})`,
     }}


      >
        <div className="card-body">

        </div>

        <div className="card-footer">

            <h5 className="headings">Summer 2021</h5>
            <p className="card-text text-start">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type</p>

        </div>

      </div>

    </div>

    </>
  );
};

export default PopularCategoriesCard1;
