import React from 'react'
import { useLocation } from 'react-router-dom'
import Footer from '../components/Footer/Footer'
import Header from '../components/Header/Header'
import MainComponent from '../components/MainComponent/MainComponent'
import PopularCategories from '../components/PopularCategories/PopularCategories'
import SummerDeals from '../components/SummerDeals/SummerDeals'
import TopCarousel from '../components/TopCarousel/TopCarousel'

function SearchSummerDeals() {
    const location = useLocation()
    console.log('location',location)
  return (
    <div>

      <Header />

    {/* <TopCarousel /> */}

    {/* <MainComponent/> */}

    <SummerDeals location = {location} />

    <PopularCategories />

    <Footer />

    </div>
  )
}

export default SearchSummerDeals;