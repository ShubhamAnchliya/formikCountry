import bg from "../../assets/bg.png";
import bg1 from "../../assets/carouselImages/bg3.jpg";

const categoriesitems = [
  {
    bgImg: bg,
    heading: "Easter 2021",
    description:
      " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's",
    // description : " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type"
  },
];
export default categoriesitems;

export const categoriesitems1 = [
  {
    bgImg1: bg1,
    heading1: "Easter 2021",
    // description : " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's"
    description1:
      " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type",
  },
];
