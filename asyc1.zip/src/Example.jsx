import React, { useState, useEffect } from "react";

import AsyncSelect from "react-select/async";

const Example = () => {
  const [page, setPage] = useState(1);
  const [items, onItemsChange] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchData(page, search);
  }, [page, search]);

  const fetchData = async (pageIdx, searchedId) => {
    const res = await fetch(
      `https://jsonplaceholder.typicode.com/todos/${searchedId}/?_limit=15&_page=${pageIdx}`

// `https://countriesnow.space/api/v0.1/countries/`
    ).then((r) => r.json());
    const resItems = res.length
      ? res
      : [res].map(({ title }) => ({
          label: title,
          value: title
        }));
    console.log(resItems);
    onItemsChange([...items, ...resItems]);
  };

  const loadOptions = (search) => {
    setSearch(search);
    return items;
  };

  const handleBottomScroll = () => {
    setPage((prevVal) => prevVal + 1);
  };

  return (
    <AsyncSelect
      cacheOptions
      isClearable={true}
      isSearchable={true}
      defaultOptions={items}
      onMenuScrollToBottom={handleBottomScroll}
      loadOptions={loadOptions}
    />
  );
};

export default Example;
