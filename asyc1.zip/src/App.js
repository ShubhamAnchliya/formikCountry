import React from 'react'
import Example from './Example';

const App = () => {
  return (
    <>
      <Example />
    </>
  )
}

export default App;