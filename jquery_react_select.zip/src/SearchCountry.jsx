
import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import { BiMapPin } from "react-icons/bi";
// import "./SearchCountry.css";
import Select from 'react-select';


const SearchCountry = () => {
  const [selectedCountry, setSelectedCountry] = useState();
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState();
  // const [selectedCategory, setSelectedCategory] = useState();
  const [submit, setSubmit] = useState("");
  const [dropdownData,setDropDownData] = useState([])
  // let options = []

  const fetchCountries = async () => {

    try {

      const countrylist = await axios.get("https://countriesnow.space/api/v0.1/countries");
      setCountries(countrylist.data.data);
      console.log( "setCountries" , countrylist.data.data);
      let countryvalue =  countrylist?.data?.data.map((i, key) => {
        
   
        
        return {value:i.country, label:i.country, cities:i.cities.map((i) => {
          return {value:i,label:i}
        })};

        // return {value:i.country};
      
        
      }) 

      setDropDownData(countryvalue)

      console.log('countryvalue',countryvalue)

    } catch (error) {

      console.log(error);
      
    }
    
  };


  // console.log("filter Countries",countries.filter(data => data.country.toLowerCase().includes("indo")));

  
  // const handlecountry = (selectedCountry) => {
  //   setSubmit(false);
  //   console.log("handle selectedCountry", selectedCountry );

    // setSelectedCountry(selectedCountry);
    console.log("SelectedCountry",selectedCountry);

    // const availableCities = countries.find((c) => c.country === selectedCountry.value);
    // console.log("ac",availableCities.cities);

  //   // setCities(availableCities.cities);

  //   // console.log("setCites", availableCities.cities);

  // };

                


 

  // const availableCategory = availableCities?.cities?.find((s) => s.name === selectedCity);

  // console.log("ac",availableCities);

  useEffect(() => {

    fetchCountries();
    
  
  }, []);

  // console.log("selectedCountry", selectedCountry );
  // console.log("selectedCity", selectedCity );





  const onSubmit = () => {

  // console.log("setselectedCountry",selectedCountry.value);

    if(selectedCountry.value
        //  && selectedCity 
      // && selectedCategory 
      ) {
      setSubmit(true);
    }
    
  };



  return (

    <>
      <div className='mainDiv packageDiv container'>

          <div className='countrySelector '> 

              <div className="form-group me-3 ">

                  <Select
                 
                    id="selectCountry" 
                    onChange={setSelectedCountry}

                    // onChange={(e) => handlecountry(e.target.value)}
                    value={selectedCountry}             
                    // defaultValue={selectedCountry}
                    options={dropdownData}
                    isSearchable={true}
                    placeholder={'Country'}

                    styles={{
                      placeholder:
                       (base) => ({
                        ...base,
                        paddingLeft: '25px'
                      }),
                      valueContainer:
                       (base) => ({
                        ...base,
                        paddingLeft: '2rem'
                      })
       
                    }}
              
                  />
                 

              </div>

             {selectedCountry ? <div className="form-group me-3">

<Select 
  name="City"
  className="form-control select-city"                 
  onChange={(e) => setSelectedCity(e.target.value)}
  value={selectedCity}
  id="selectCity"
  options={selectedCountry?.cities}
/>





</div> : null} 


              {/* <div className="form-group me-3">

              <select 
                name="Category"
                className="form-control  select-category " 
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedCategory}
                id="selectCategory"
              >

                <option>
                  Select Category
                </option>

                {availableCategory?.categories.map((e, key) => {
                    return (
                      <option value={e.name} key={key}>
                        {e}
                      </option>
                    );
                  })}

              </select>

              </div> */}


            <button  className='searchpackagebtn ' 
            type='button'
             onClick={onSubmit} 
             >Search</button>

          </div>
        

          { submit && (
            <h3 className='headingC mt-3'>country {selectedCountry.value}
            {/* ,  city {selectedCity}  */}
            {/* and category {selectedCategory}  */}
            </h3>
          )}


      </div>
      
    </>
  )
}

export default SearchCountry;






// import React, { useState } from 'react';
// import Select from 'react-select';

// const options = [
//   { value: 'chocolate', label: 'Chocolate' },
//   { value: 'strawberry', label: 'Strawberry' },
//   { value: 'vanilla', label: 'Vanilla' },
// ];

// export default function SearchCountry() {
//   const [selectedOption, setSelectedOption] = useState(null);

//   return (
//     <div className="App">
//       <Select
//         defaultValue={selectedOption}
//         onChange={setSelectedOption}
//         options={options}
//       />
//     </div>
//   );
// }