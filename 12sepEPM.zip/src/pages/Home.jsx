import React from 'react'
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import PopularCategories from '../components/PopularCategories/PopularCategories';
import SummerDeals from '../components/SummerDeals/SummerDeals';
import TopCarousel from '../components/TopCarousel/TopCarousel';

const Home = () => {
  return (
    <>

      <Header />

      <TopCarousel />



      

      <SummerDeals />

      <PopularCategories />

      <Footer />

    </>
  )
}

export default Home;