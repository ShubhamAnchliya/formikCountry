import flight from "../../assets/icons/flight.svg";
import room from "../../assets/icons/room.svg";
import bg from "../../assets/bg.png";

const Items = [
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "1",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "2",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "3",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "4",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "5",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },
    {
        hotel: "Heraklion",
        country : "Greece",
        days : "6",
        amount : "€500",
        imgSrc1 : flight,
        imgSrc2 : room, 
        bgImg: bg,
        description : " ΗΡΑΚΛΕΙΟ Η ΠΟΛΗ–ΛΙΜΑΝΙ ΤΗΣ ΜΕΣΟΓΕΙΟΥ ΚΑΙ ΤΗΣ ΙΣΤΟΡΙΑΣ Σφύζει από ζωή, χαρίζοντάς σας πληθώρα απολαύσεων. Μια πόλη γενναιόδωρη και αυθεντική. Το χτες και το σήμερα σε μια αρμονική συνύπαρξη….!!!"
    },


 
];

export default Items;