import React, { Component } from 'react'
import SummerDealsCard from './SummerDealsCard';
import "./SummerDeals.css";
import Slider from "react-slick";
import "../../../node_modules/slick-carousel/slick/slick.css"
import "../../../node_modules/slick-carousel/slick/slick-theme.css";
import { BsArrowLeft, BsArrowRight } from 'react-icons/bs';
import Items from './Items';

export default class SummerDeals extends Component {
  constructor(props) {
    super(props);
    this.next = this.next.bind(this);
    this.previous = this.previous.bind(this);
  }
  next() {
    this.slider.slickNext();
  }
  previous() {
    this.slider.slickPrev();
  }
  render() {
    const settings = {
      infinite: true,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 1,
      swipe: false,
      arrows: false,
      centerMode: false,
    
      responsive: [
        {
          breakpoint: 1116,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            initialSlide: 1,
            // style : {marginRight: '-55px'}
                       
          }
        },
        {
          breakpoint: 980,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
        
            initialSlide: 1,
            // style : {marginRight: '-55px'}
            style : {marginRight: '-4rem'},
          }
        },
        {
          breakpoint: 860,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            initialSlide: 1,
            // rows: 2,
           
            slidesPerRow: 1,
           
          
          }
        },
        {
          breakpoint: 780,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            initialSlide: 1,
            // rows: 2,
            slidesPerRow: 1,
            
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            
          }
        }
      ]
      
    };
    return (

      <div>

        <div className="container mt-4 ">

         <h3 className='heading'>Summer deals</h3>

          <span style={{
           

              float:'right',
              color: "blue",

            }}
            className="arrows"


          > 
            <span  onClick={this.previous} 
              // className="arrows"
            >
              <BsArrowLeft />
            </span>

            <span onClick={this.next}
              // className="arrows"
            >
              <BsArrowRight />
            </span>

          </span>  

          <Slider  ref={c => (this.slider = c)}  {...settings}>
  
            {Items && Items.map((item, idx)=> {

              return (

                <SummerDealsCard 
                  
                  key={idx} 
                  hotel={item.hotel}
                  country={item.country}
                  days={item.days}
                  imgSrc1={item.imgSrc1}
                  imgSrc2={item.imgSrc2}
                  bgImg={item.bgImg}
                  amount ={item.amount}
                  description ={item.description}

                />
              
                )
            })}
                                
          </Slider>          
         
        </div>

      </div>
    );
  }
};