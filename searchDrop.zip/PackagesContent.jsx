
import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import { BiMapPin } from "react-icons/bi";
import "./PackagesContent.css";


const PackagesContent = () => {
  const [selectedCountry, setSelectedCountry] = useState();
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState();
  // const [selectedCategory, setSelectedCategory] = useState();
  const [submit, setSubmit] = useState("");

  const fetchCountries = async () => {

    try {

      const countrylist = await axios.get("https://countriesnow.space/api/v0.1/countries");
      setCountries(countrylist.data.data);
      console.log( "setCountries" , countrylist.data.data);

    } catch (error) {

      console.log(error);
      
    }
    
  };


  const handlecountry = (selectedCountry) => {
    setSubmit(false);
  

    setSelectedCountry(selectedCountry);
    // console.log("setSelectedCountry",setSelectedCountry(selectedCountry));

    const availableCities = countries.find((c) => c.country === selectedCountry);
    // console.log("ac",availableCities.cities);

    setCities(availableCities.cities);

    console.log("setCites", availableCities.cities);

  };


 

  // const availableCategory = availableCities?.cities?.find((s) => s.name === selectedCity);

  // console.log("ac",availableCities);

  useEffect(() => {

    fetchCountries();
    
  
  }, []);

  console.log("selectedCountry", selectedCountry );
  console.log("selectedCity", selectedCity );

  const onSubmit = () => {

    if(selectedCountry && selectedCity 
      // && selectedCategory 
      ) {
      setSubmit(true);
    }
    
  };



  return (

    <>
      <div className='mainDiv packageDiv container'>

          <div className='countrySelector '>

              <div className="form-group me-3">

                  <select 
                    name="Country"
                    className="form-control select-country "
                    id="selectCountry" 
                    onChange={(e) => handlecountry(e.target.value)}
                    value={selectedCountry}             
            
                   >
                  
                    <option  value="" >
                      Select Country 
                    </option>

                    {countries.map((value, key) => {
                      return (
                        <option  value={value.country} key={key}>
                          {value.country}
                        </option>
                      );
                    })}

                 

                  </select>

              </div>

              <div className="form-group me-3">

                  <select 
                    name="City"
                    className="form-control select-city"                 
                    onChange={(e) => setSelectedCity(e.target.value)}
                    value={selectedCity}
                    id="selectCity"
                  >

                    <option>
                      Select City
                    </option>

                    {cities.map((e, key) => {
                      return (
                        <option value={e} key={key}>
                          {e}
                        </option>
                      );
                    })}

                  </select>

              </div>


              {/* <div className="form-group me-3">

              <select 
                name="Category"
                className="form-control  select-category " 
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedCategory}
                id="selectCategory"
              >

                <option>
                  Select Category
                </option>

                {availableCategory?.categories.map((e, key) => {
                    return (
                      <option value={e.name} key={key}>
                        {e}
                      </option>
                    );
                  })}

              </select>

              </div> */}


            <button  className='searchpackagebtn ' 
            type='button'
             onClick={onSubmit} 
             >Search</button>

          </div>
        

          { submit && (
            <h3 className='headingC mt-3'>country {selectedCountry},  city {selectedCity} 
            {/* and category {selectedCategory}  */}
            </h3>
          )}


      </div>
      
    </>
  )
}

export default PackagesContent;