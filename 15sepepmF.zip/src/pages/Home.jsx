import React from "react";
import { useState } from "react";
import Footer from "../components/Footer/Footer";
import Header from "../components/Header/Header";
import PopularCategories from "../components/PopularCategories/PopularCategories";
import TopCarousel from "../components/TopCarousel/TopCarousel";
import { createContext } from "react";
import SummerDeals from "../components/SummerDeals/SummerDeals";

export const SearchContext = createContext();

const Home = () => {
  const [searchData, setSearchData] = useState("");
  console.log("searchData", searchData);
  return (
    <>
      <SearchContext.Provider value={{ searchData, setSearchData }}>

        <Header />

        {/* <TopCarousel /> */}

        <SummerDeals location={searchData} />

        <PopularCategories />

        <Footer />
        
      </SearchContext.Provider>
    </>
  );
};

export default Home;
