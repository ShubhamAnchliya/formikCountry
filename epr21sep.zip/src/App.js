import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import PackageSearch from "./pages/PackageSearch";
import SearchPage from "./pages/PackageSearch";

const App = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        {/* <Route path="/searchpackage" element={<PackageSearch />} /> */}
      </Routes>
    </>
  );
};

export default App;
