import React, { createContext, useState } from 'react'
import { useLocation } from 'react-router-dom';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header'
import PopularCategories from '../components/PopularCategories/PopularCategories';
import SummerDeals from '../components/SummerDeals/SummerDeals';
export const SearchContext = createContext();


const PackageSearch = () => {
  const location = useLocation()
  console.log('location',location)
  const [searchData, setSearchData] = useState("");
  console.log("searchData", searchData);
  return (
    <>
      <SearchContext.Provider value={{ searchData, setSearchData }}>
            <Header />
            {/* <TopCarousel /> */}
            <SummerDeals location={searchData} />
         
            <Footer />
        </SearchContext.Provider>
    </>
  )
}

export default PackageSearch;