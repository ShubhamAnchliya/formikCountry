import React from "react";
import "./PopularCategories.css";
// import categoriesitems, { categoriesitems1 } from "./categoriesitems";
import PopularCategoriesCard2 from "./PopularCategoriesCard2";
import PopularCategoriesCard1 from "./PopularCategoriesCard1";

const PopularCategories = () => {
  return (
    <>
      <div className="container mt-4">
        <h3 className="categoriesheading">Popular Categories</h3>

        <div className="cardsDiv row">
          <div style={{ display: "contents" }}>
            <PopularCategoriesCard1 />
            <PopularCategoriesCard2 />
            <PopularCategoriesCard2 />
            <PopularCategoriesCard1 />
          </div>
        </div>
      </div>
    </>
  );
};

export default PopularCategories;
