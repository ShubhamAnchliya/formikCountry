import React from "react";
import "./PopularCategoriesCard2.css";
import bgImg2 from "../../assets/bg.png";

const PopularCategoriesCard2 = () => {
  return (
    <>
      <div className="categoriescard  my-2 mb-4">
        <div
          className="card"
          style={{
            backgroundImage: `url(${bgImg2})`,
          }}
        >
          <div className="card-body"></div>

          <div className="card-footer">
            <h5 className="headings">Easter 2021</h5>
            <p className="card-text text-start">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default PopularCategoriesCard2;
