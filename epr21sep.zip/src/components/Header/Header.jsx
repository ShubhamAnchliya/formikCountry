import React from "react";
import Navbar from "../Navbar/Navbar";
import SearchBarHeader from "../SearchBarHeader/SearchBarHeader";
import Topbar from "../Topbar/Topbar";
import "./Header.css";

const Header = () => {
  return (
    <>
      <Topbar />
      <Navbar />
      <SearchBarHeader />
    </>
  );
};

export default Header;
