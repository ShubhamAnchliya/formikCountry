import React, { useState } from "react";
import SummerDealsCard from "./SummerDealsCard";
import "./SummerDeals.css";
import Slider from "react-slick";
import "../../../node_modules/slick-carousel/slick/slick.css";
import "../../../node_modules/slick-carousel/slick/slick-theme.css";
import { BsArrowLeft, BsArrowRight } from "react-icons/bs";
import Items from "./Items";
import { useEffect } from "react";

const SummerDeals = (props) => {
  const [sliderRef, setSliderRef] = useState(null);
  const [sliderChange, setSliderChange] = useState(0);

  const sliderSettings = {
    arrows: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    infinite: false,
    // infinite: true,
    speed: 500,

    swipe: false,

    afterChange: (change) => setSliderChange(change),

    responsive: [
      {
        breakpoint: 1116,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          // initialSlide: 1,
        },
      },
      {
        breakpoint: 980,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          // initialSlide: 1,
          style: { marginRight: "-4rem" },
        },
      },
      {
        breakpoint: 860,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          // initialSlide: 1,
          slidesPerRow: 1,
        },
      },
      {
        breakpoint: 780,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          // initialSlide: 1,
          slidesPerRow: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  useEffect(() => {
    console.log("sliderRef", sliderChange);
  }, [sliderChange]);

  function HandlePrev() {
    return sliderRef?.slickPrev();
  }

  function HandleNext() {
    console.log("sliderRef", sliderRef);
    if (sliderChange < sliderRef?.props?.children.length) {
      return sliderRef?.slickNext();
    } else {
      return null;
    }
  }

  return (
    <>
      <div className="contentF container mt-4 ">
        <h3 className="headingF">Summer deals</h3>

        <div
          className="arrows"
          style={{
            float: "right",
            color: "blue",
            fontSize: "25px",
          }}
        >
          <span onClick={() => HandlePrev()}>
            <BsArrowLeft />
          </span>

          {sliderChange < sliderRef?.props?.responsive?.length ? (
            <span onClick={() => HandleNext()}>
              <BsArrowRight />
            </span>
          ) : null}
        </div>

        <Slider ref={(slider) => setSliderRef(slider)} {...sliderSettings}>
          {Items &&
            Items.filter((i) => {
              console.log("props?.location", props);

              if (
                i.country.toLowerCase().includes(props?.location.toLowerCase())
              ) {
                console.log("i", i);
                return i;
              }
              if (props?.location === null) {
                console.log("i2", i);
                return i;
              }
            }).map((item, idx) => {
              return (
                <SummerDealsCard
                  key={idx}
                  hotel={item.hotel}
                  country={item.country}
                  days={item.days}
                  imgSrc1={item.imgSrc1}
                  imgSrc2={item.imgSrc2}
                  bgImg={item.bgImg}
                  amount={item.amount}
                  description={item.description}
                />
              );
            })}
        </Slider>
      </div>
    </>
  );
};

export default SummerDeals;
