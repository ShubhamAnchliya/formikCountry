import React from "react";

const FerriesContent = () => {
  return (
    <div className="ferriesContent  text-center">
      Lorem Ipsum is probably the most popular dummy text generator out there
    </div>
  );
};

export default FerriesContent;
