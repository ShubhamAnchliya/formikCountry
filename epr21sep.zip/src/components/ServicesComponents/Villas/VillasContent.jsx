import React, { useState } from "react";
import "./VillasContent.css";
import { BiMapPin } from "react-icons/bi";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { AiTwotoneCalendar } from "react-icons/ai";
import { MdOutlineHotel } from "react-icons/md";
import { BsDoorClosed } from "react-icons/bs";

const VillasContent = () => {
  const [startDate, setStartDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(new Date());

  return (
    <>
      <div className="villasContent">
        <div className="villasContent-two mt-3">
          <div className="input-wrapper me-2">
            <input className="location" placeholder="Location" />
            <label className="input-icon">
              <BiMapPin />
            </label>
          </div>

          <div className="input-wrapperd me-2">
            <DatePicker
              className="input"
              dateFormat="dd MMM"
              selected={startDate}
              minDate={new Date()}
              maxDate={new Date(2023, 1, 29)}
              onChange={(date) => setStartDate(date)}
            />

            <label className="input-icon2">
              <AiTwotoneCalendar />
            </label>

            <label className="input-icon3">Check in</label>
          </div>

          <div className="input-wrapperd  me-2">
            <DatePicker
              className="input"
              dateFormat="dd MMM"
              selected={returnDate}
              minDate={new Date()}
              maxDate={new Date(2023, 1, 29)}
              onChange={(date) => setReturnDate(date)}
            />

            <label className="input-icon2">
              <AiTwotoneCalendar />
            </label>

            <label className="input-icon3">Check out</label>
          </div>

          <div className="input-wrapperd me-2">
            <select
              className="form-control"
              aria-label="Default select example"
            >
              {Array(5)
                .fill(0)
                .map((item, idx) => (
                  <option defaultValue="1" key={idx}>
                    {idx + 1} Adults
                  </option>
                ))}
            </select>

            <label className="input-icon2">
              <MdOutlineHotel />
            </label>

            <label className="input-icon3">Guests</label>
          </div>

          <div className="input-wrapperd me-2">
            <select
              className="form-control"
              aria-label="Default select example"
            >
              {Array(5)
                .fill(0)
                .map((item, idx) => (
                  <option defaultValue="1" key={idx}>
                    {idx + 1} Rooms
                  </option>
                ))}
            </select>

            <label className="input-icon2">
              <BsDoorClosed />
            </label>

            <label className="input-icon3">Rooms</label>
          </div>

          <button className="villassearchbtn " type="button">
            Search
          </button>
        </div>
      </div>
    </>
  );
};

export default VillasContent;
