import React from "react";
import Carouselbg from "./Carouselbg";
import "./TopCarousel.css";

import { IoIosArrowDropleft, IoIosArrowDropright } from "react-icons/io";

const TopCarousel = () => {
  return (
    <>
      <div
        id="carouselExampleControlsNoTouching"
        className="carousel slide"
        data-bs-touch="false"
        data-bs-interval="false"
      >
        <div className="carousel-inner">
          {Carouselbg &&
            Carouselbg.map((item, idx) => {
              return (
                <div className="carousel-item active" key={idx}>
                  <img
                    src={item.carouselbg}
                    className="d-block w-100"
                    alt="slide1"
                    style={{ height: "280px" }}
                  />

                  <div
                    className="carousel-caption "
                    style={{ bottom: "5.25rem" }}
                  >
                    <h2>{item.carouseltext}</h2>
                  </div>
                </div>
              );
            })}
        </div>

        <button
          className="carousel-control-prev  carousel-control"
          type="button"
          data-bs-target="#carouselExampleControlsNoTouching"
          data-bs-slide="prev"
        >
          <span className="previousc" aria-hidden="true">
            <IoIosArrowDropleft />
          </span>
          <span className="visually-hidden">Previous</span>
        </button>

        <button
          className="carousel-control-next carousel-control "
          type="button"
          data-bs-target="#carouselExampleControlsNoTouching"
          data-bs-slide="next"
        >
          <span className="nextc" aria-hidden="true">
            <IoIosArrowDropright />
          </span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
    </>
  );
};

export default TopCarousel;
