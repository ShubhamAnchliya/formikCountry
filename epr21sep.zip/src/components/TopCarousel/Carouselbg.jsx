import bg1 from "../../assets/carouselImages/bg2.jpg";
import bg2 from "../../assets/carouselImages/bg3.jpg";

const Carouselbg = [
  {
    carouselbg: bg1,
    carouseltext:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    carouselbg: bg2,
    carouseltext:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry2.",
  },
];

export default Carouselbg;
