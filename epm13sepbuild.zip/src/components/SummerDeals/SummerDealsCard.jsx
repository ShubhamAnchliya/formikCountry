import React from "react";
import "./SummerDealsCard.css";

const SummerDealsCard = (props) => {
  console.log("props", props);
  return (
    <>
 
        <div
          className="card mb-4"
          style={{
            backgroundImage: `url(${props.bgImg})`,
          }}
        >
          <div className="card-body">
            <div className="d-flex justify-content-between">
              <div className="text-start">
                <p className="mb-0">{props.hotel}</p>
                <p className="mb-0 text-uppercase">
                  {props.country}
                </p>
              </div>
              <div className="d-flex flex-column">
                <div className="d-flex gap-2">
                  <span>
                    <img src={props.imgSrc1} alt="flight" />
                  </span>
                  <span>
                    <img src={props.imgSrc2} alt="rooms" />
                  </span>
                  <span className="days"> days</span>
                </div>
                <p className="amount"></p>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <p className="card-text text-start">{props.description}</p>
          </div>
        </div>

    </>
  );
};

export default SummerDealsCard;
