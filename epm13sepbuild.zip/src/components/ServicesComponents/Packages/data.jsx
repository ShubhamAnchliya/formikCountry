

const data = {
    countries : [

        { name: 'Philippines',
          cities: [ 
            {
                name: 'Angeles City', 
                categories: ['category1', 'category2', 'category3']
            },
           
            {
                name: 'Olongapo', 
                categories:  ['category4', 'category5', 'category6']
            }
          ]
        },

        { name: 'United States of America', cities: [ 
            {name: 'Sacramento',categories: ['category1', 'category2', 'category3']},
            {name: 'Chicago', categories: ['category4', 'category5', 'category6']},
            {name: 'Los Angeles', categories: ['category7', 'category8', 'category9']}
        ]},
             
    ]
}

export default data;