import React from 'react';

const CruisesContent = () => {
  return (
    <div className='cruisesContent  text-center'>Lorem Ipsum is probably the most popular dummy text generator out there</div>
  )
}

export default CruisesContent;