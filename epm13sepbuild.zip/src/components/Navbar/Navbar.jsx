import React from 'react';
import { Link } from 'react-router-dom';
import logo from "../../assets/icons/logo.jpeg";


const Navbar = () => {
  return (
    <>

        <nav className="navbar navbar-expand-lg bg-light text-center ">
            <div className="container-fluid" style={{marginLeft: '11.8rem'}}>
            <Link className="navbar-brand" to="/">
                <img src={logo} alt="" width="90" height="40" />
            </Link>

            <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarNavDropdown">
                <ul className="navbar-nav ">
                <li className="nav-item dropdown mx-3">
                    <a
                    className="nav-link dropdown-toggle active "
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    >
                    Packages
                    </a>
                    <ul className="dropdown-menu">
                    <li>
                        <a className="dropdown-item" href="#">
                        Package 1
                        </a>
                    </li>
                    <li>
                        <a className="dropdown-item" href="#">
                        Package 2
                        </a>
                    </li>
                    <li>
                        <a className="dropdown-item" href="#">
                        Package 3
                        </a>
                    </li>
                    </ul>
                </li>

                <li className="nav-item dropdown mx-3">
                    <a
                    className="nav-link dropdown-toggle active "
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    >
                    Travel Guides
                    </a>
                    <ul className="dropdown-menu">
                    <li>
                        <a className="dropdown-item" href="#">
                        Travel Guide 1
                        </a>
                    </li>
                    <li>
                        <a className="dropdown-item" href="#">
                        Travel Guide 2
                        </a>
                    </li>
                    <li>
                        <a className="dropdown-item" href="#">
                        Travel Guide 3
                        </a>
                    </li>
                    </ul>
                </li>

                <li className="nav-item mx-2">
                    <a className="nav-link active" aria-current="page" href="#">
                    Travel Insurances
                    </a>
                </li>
                <li className="nav-item mx-2">
                    <a className="nav-link active" href="#">
                    Gift Card
                    </a>
                </li>

                <li className="nav-item text-center ms-5 languageSelect m-auto">
                    <a href="" className="fw-bold">EN</a>
                    <small className="px-1 fw-bold">|</small>
                    <a href="">GR</a>
                </li>

                <li className="nav-item mx-4 m-auto">
                    <a className="btn  btn-sm btn-primary" href="#" role="button">
                    Log In
                    </a>
                </li>
                
                </ul>
            </div>
            </div>
        </nav>

    </>
  )
}

export default Navbar;