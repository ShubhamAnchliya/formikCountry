import React from 'react'
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import SearchSummerDeals from './pages/SearchSummerDeals';

const App = () => {
  return (
    <>
      <Routes>

          <Route path='/' element={<Home />}    />
          <Route path="/search" element={<SearchSummerDeals /> } />
      </Routes>
    </>
  )
}

export default App;