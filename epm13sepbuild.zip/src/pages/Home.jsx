import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import MainComponent from '../components/MainComponent/MainComponent';
import PopularCategories from '../components/PopularCategories/PopularCategories';
import SummerDeals from '../components/SummerDeals/SummerDeals';
import TopCarousel from '../components/TopCarousel/TopCarousel';
import { createContext } from 'react';

export const SearchContext = createContext()
const Home = () => {

  const [searchData,setSearchData] = useState('')
  console.log('searchData',searchData)
  return (
    <>
      <SearchContext.Provider value={{searchData,setSearchData}}>
      <Header />

      {/* <TopCarousel /> */}

      {/* <MainComponent/> */}

{/* <SearchContext.Consumer> */}
{/* {setInterval(() => {console.log("helloppppppppppp",searchData)},500)} */}
      <SummerDeals location={searchData} />
{/* // </SearchContext.Consumer> */}

      <PopularCategories />

      <Footer />
      </SearchContext.Provider>
    </>
  )
}

export default Home;