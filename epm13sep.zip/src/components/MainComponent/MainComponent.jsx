import React from 'react'

const MainComponent = () => {
  return (
    <>MainComponent</>
  )
}

export default MainComponent;