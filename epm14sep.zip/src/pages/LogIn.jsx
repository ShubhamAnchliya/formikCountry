import React from 'react'

const LogIn = () => {
  return (
    <>
        LogIn
    </>
  )
}

export default LogIn;