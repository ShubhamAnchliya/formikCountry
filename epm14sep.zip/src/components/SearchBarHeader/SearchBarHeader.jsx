import React, { useState } from 'react';
import "./SearchBarHeader.css";
import ServicesSearchTab from './ServicesSearchTab';



// const Toggle = () => {
//     const [show, toggleShow] = React.useState(true);
    
//     return (
//       <div>
//         <button onClick={() => toggleShow(!show)}>toggle: {show ? 'show' : 'hide'}</button>    
//         {show && <div>Hi there</div>}
//       </div>
//     )
//   }


const SearchBarHeader = () => {

    const [showSearchBar, setshowSearchBar] = useState();


  return (
    <>

    { 
        showSearchBar ?

            <div className="container-fluid d-inline-flex showSearchDiv ">            

                <ServicesSearchTab/>
             
                
                <button 
                    className="btn text-center searchbtn " 
                    type="button" 
                    onClick={() => setshowSearchBar(!showSearchBar) } > { showSearchBar ? 'Hide ' : 'Show '}
                        Search Button
                </button>
                
            </div>

        :

            <div className="container-fluid d-inline-flex " style={{background: "#0073cf" }} >

                <span className="py-3 text-white" style={{ marginLeft:'20rem'}}>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </span>

                <button 
                className="btn btn-primary text-center searchbtn border border-white" 
                type="button" 
                onClick={() => setshowSearchBar(!showSearchBar) } > { showSearchBar ? 'Hide ' : 'Show '}
                    Search Button
                </button>

            </div>

    }

    </>
  )
}

export default SearchBarHeader;