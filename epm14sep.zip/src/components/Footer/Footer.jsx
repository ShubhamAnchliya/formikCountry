import React from 'react';
import "./Footer.css";
import logo from "../../assets/icons/logo.jpeg";
import { HiArrowRight } from 'react-icons/hi';

import { RiFacebookFill, RiInstagramLine } from 'react-icons/ri';


const Footer = () => {
  return (
    <>
      <footer className="footer-section mt-5">

        <div className="container">

            <div className="footer-cta pt-4 pb-4">

                    <div className="footerImgDiv">
                        <img src={logo} alt="" className=' mx-auto d-block' width="100" height="40" /> 
                    </div>
            </div>

            <div className="footer-content pt-4 pb-4 footer-cta">
                <div className="row">


                <div className="col-lg-3">
                    <div className="">
                        <h6 className="footer-heading text-uppercase text-white">Services</h6>
                        <ul className="list-unstyled footer-link">
                            <li><a href="">PACKAGES</a></li>
                            <li><a href="">FLIGHTS</a></li>
                            <li><a href="">CHARTER FLIGHTS</a></li>
                            <li><a href="">CRUISES</a></li>
                            <li><a href="">FERRIES</a></li>
                            <li><a href="">CAR RENTAL</a></li>
                            <li><a href="">VILLAS</a></li>
                            
                        </ul>
                    </div>
                </div>

                <div className="col-lg-3">
                    <div className="">
                        <h6 className="footer-heading text-uppercase text-white">TRAVEL GUIDES</h6>
                        <ul className="list-unstyled footer-link ">
                            <li><a href="">EXOLORERS GUIDE </a></li>
                            <li><a href="">AIRLINE GUIDE </a></li>
                            <li><a href="">HONEYMOON GUIDE </a></li>
                            <li><a href="">CYPRUS</a></li>
                            <li><a href="">CRUISES CATALOGUE 2021</a></li>
                            <li><a href="">SUMMER CATALOGUE 2021</a></li>
                        </ul>
                    </div>
                </div>

                <div className="col-lg-2 flex-column">
                    <div className="">

                        <h6 className="footer-heading text-uppercase text-white">ABOUT US</h6>
                        <ul className="list-unstyled footer-link ">
                            <li><a href="">WHO WE ARE</a></li>
                            <li><a href="">CONTACT US</a></li>                        
                        </ul>
                

                        <h6 className="footer-heading text-uppercase text-white mt-4">OTHER SERVICES</h6>
                        <ul className="list-unstyled footer-link">
                            <li><a href="">TRAVEL INSURANCE</a></li>
                            <li><a href="">GIFT CARDS</a></li>
                            <li><a href="">BLOG</a></li>
                            <li><a href="">CONFERENCES</a></li>
                        </ul>

                    </div>
                </div>

     









                <div className="col-lg-4">
                    <div className="">
                        <h6 className="footer-heading text-uppercase text-white">NEVER MISS AN OFFER</h6>

                        <div className="signup_form">                           
                                <form action="#" className="subscribe">
                                    <input type="text" className="subscribe__input" placeholder="Enter your email address" />
                                    <button type="button" className="subscribe__btn"><HiArrowRight /></button>
                                </form>
                        </div>


                        <h6 className="contact-info mt-4">Customer Support</h6>
                        <p className="contact-infop">77 78 78 78 / +357 22713755</p>
                        <p className="contact-infop">callcenter@topkinisis.com</p>
                        <div className="mt-4">
                            <ul className="list-inline">
                                <li className="list-inline-item footer-social-icon"><a href="#"><RiFacebookFill  color="white" fontSize="1.5em" /></a></li>
                                <li className="list-inline-item footer-social-icon"><a href="#"><RiInstagramLine color="white" fontSize="1.5em" /></a></li>
                            </ul>
                        </div>
                    </div>
                </div>






          
                </div>
            </div>

        </div>

        <div className="copyright-area ">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6 col-lg-6 text-lg-left">
                        <div className="copyright-text">
                            <p>&copy; 2021 TOP KINISIS</p>
                        </div>
                    </div>
                    <div className="col-xl-6 col-lg-6 d-none d-lg-block ">
                        <div className="footer-menu">
                            <ul>
                                 <li><a href="#">Privacy Policy</a></li>
                            
                                <li><a href="#">Terms of Service</a></li>
                               
                                <li><a href="#">Online Dispute Resolution</a></li>
                                <li><a href="#">Regulations</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

      </footer>
    </>
  )
}

export default Footer;