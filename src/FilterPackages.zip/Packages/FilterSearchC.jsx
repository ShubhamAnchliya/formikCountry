import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BiMapPin } from "react-icons/bi";
import "./FilterSearchC.css";
import Select from 'react-select';


const FilterSearchC = () => {

  const [selectedCountry, setSelectedCountry] = useState();
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState();
  // const [selectedCategory, setSelectedCategory] = useState();
  const [submit, setSubmit] = useState("");
  // const [dropdownData,setDropDownData] = useState([])
  // let options = []

  const fetchCountries = async () => {

    try {

      const countrylist = await axios.get("https://countriesnow.space/api/v0.1/countries");
      setCountries(countrylist.data.data);
      console.log( "setCountries" , countrylist.data.data);
      
      // let countryvalue =  countrylist?.data?.data.map((i, key) => {
        
      //   return {value:i.country, label:i.country};

      //   return {value:i.country};
      
        
      // }) 

      // setDropDownData(countryvalue)

      // console.log('countryvalue',countryvalue)

    } catch (error) {

      console.log(error);
      
    }
    
  };


  // console.log("filter Countries",countries.filter(data => data.country.toLowerCase().includes("indo")));

  
  const handlecountry = (selectedCountry) => {
    setSubmit(false);
    console.log("handle selectedCountry", selectedCountry );

    setSelectedCountry(selectedCountry);
    console.log("SelectedCountry",selectedCountry);

    const availableCities = countries.find((c) => c.country === selectedCountry);
    console.log("ac",availableCities.cities);

    setCities(availableCities.cities);

    console.log("setCites", availableCities.cities);

  };

                


 

  // const availableCategory = availableCities?.cities?.find((s) => s.name === selectedCity);

  // console.log("ac",availableCities);

  useEffect(() => {

    fetchCountries();
    
  }, []);

  // console.log("selectedCountry", selectedCountry );
  // console.log("selectedCity", selectedCity );





  const onSubmit = () => {

  // console.log("setselectedCountry",selectedCountry.value);

    if(selectedCountry
         && selectedCity 
      // && selectedCategory 
      ) {
      setSubmit(true);
    }
    
  };



  return (

    <>
      <div className='mainDiv packageDiv container'>

          <div className='countrySelector '> 

              <div className="form-group me-3 ">

                  <input                
                    id="selectCountry" 
                    // onChange={setSelectedCountry}

      
                    onChange={(e) => handlecountry(e.target.value)}
                    value={selectedCountry}             
 
                    // placeholder={'Country'}

                  
              
                  />
                  
                  {/* <label className="input-icon"><BiMapPin /></label> */}
                  

                   

       

                 <ul style={{backgroundColor: "whitesmoke"}}>
  
                    {countries
                    .filter(value => value.country.toLowerCase().includes(selectedCountry))
                    .slice(0, 10)
                    .map((value, key) => {
                   
                      return (
                        <ol  onClick={(e) => handlecountry(value.country)} value={value.country}  key={key}>
                          {value.country}
                        </ol>

                      );
                    })}

                    </ul>   

                 

              </div>

              <div className="form-group me-3">

                  <input 
                    name="City"
                    className="form-control select-city"       
                     list="datalistOptions"          
                    onChange={(e) => setSelectedCity(e.target.value)}
                    value={selectedCity}
                    id="selectCity"
                    />

                    {/* <option>
                      Select City
                    </option> */}
                    <datalist id="datalistOptions">
                    {cities.map((e, key) => {
                      return (
                      
                          <option value={e} key={key}>
                            {e}
                          </option>
                       
                      );
                    })}
                    </datalist>

                  {/* </input> */}

              </div>


              {/* <div className="form-group me-3">

              <select 
                name="Category"
                className="form-control  select-category " 
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedCategory}
                id="selectCategory"
              >

                <option>
                  Select Category
                </option>

                {availableCategory?.categories.map((e, key) => {
                    return (
                      <option value={e.name} key={key}>
                        {e}
                      </option>
                    );
                  })}

              </select>

              </div> */}


            <button  className='searchpackagebtn ' 
            type='button'
             onClick={onSubmit} 
             >Search</button>

          </div>
        

          { submit && (
            <h3 className='headingC mt-3'>country {selectedCountry}
            ,  city {selectedCity} 
            {/* and category {selectedCategory}  */}
            </h3>
          )}


      </div>
      
    </>
  )
}

export default FilterSearchC;






// import React, { useState } from 'react';
// import Select from 'react-select';

// const options = [
//   { value: 'chocolate', label: 'Chocolate' },
//   { value: 'strawberry', label: 'Strawberry' },
//   { value: 'vanilla', label: 'Vanilla' },
// ];

// export default function filterSearch() {
//   const [selectedOption, setSelectedOption] = useState(null);

//   return (
//     <div className="App">
//       <Select
//         defaultValue={selectedOption}
//         onChange={setSelectedOption}
//         options={options}
//       />
//     </div>
//   );
// }